package com.multiverse;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.settings.KeyBinding;
import net.minecraftforge.client.IRenderHandler;
import net.minecraftforge.client.event.EntityViewRenderEvent;
import net.minecraftforge.event.terraingen.BiomeEvent;
import net.minecraftforge.fml.common.eventhandler.SubscribeEvent;
import net.minecraftforge.fml.common.gameevent.TickEvent;
import org.lwjgl.input.Keyboard;

public class ClientEvents {
    public static final KeyBinding KEY = new KeyBinding("Renk ayarları", Keyboard.KEY_K, "Multiverse");

    private Theme theme() {
        Minecraft mc = Minecraft.getMinecraft();
        if (mc.world == null) return null;
        return Themes.byDimension(mc.world.provider.getDimension());
    }

    @SubscribeEvent
    public void grass(BiomeEvent.GetGrassColor e) {
        if (ColorSettings.customGrass) {
            e.setNewColor(ColorSettings.grass);
        } else {
            Theme t = theme();
            if (t != null) e.setNewColor(t.grass);
        }
    }

    @SubscribeEvent
    public void fog(EntityViewRenderEvent.FogColors e) {
        int c;
        if (ColorSettings.customSky) {
            c = ColorSettings.sky;
        } else {
            Theme t = theme();
            if (t == null) return;
            c = t.sky;
        }
        e.setRed(((c >> 16) & 255) / 255f);
        e.setGreen(((c >> 8) & 255) / 255f);
        e.setBlue((c & 255) / 255f);
    }

    @SubscribeEvent
    public void tick(TickEvent.ClientTickEvent e) {
        if (e.phase != TickEvent.Phase.END) return;
        Minecraft mc = Minecraft.getMinecraft();
        WorldClient w = mc.world;
        if (w != null && Themes.byDimension(w.provider.getDimension()) == null) {
            IRenderHandler cur = w.provider.getSkyRenderer();
            if (ColorSettings.customSky) {
                if (!(cur instanceof ClientHooks.SkyDome)) w.provider.setSkyRenderer(new ClientHooks.SkyDome());
            } else if (cur instanceof ClientHooks.SkyDome) {
                w.provider.setSkyRenderer(null);
            }
        }
        if (KEY.isPressed() && mc.currentScreen == null) {
            mc.displayGuiScreen(new GuiColorSettings());
        }
    }
}
