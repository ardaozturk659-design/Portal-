package com.multiverse;

import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraftforge.client.ClientCommandHandler;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.fml.client.registry.ClientRegistry;
import net.minecraftforge.fml.client.registry.IRenderFactory;
import net.minecraftforge.fml.client.registry.RenderingRegistry;
import net.minecraftforge.fml.common.event.FMLPreInitializationEvent;

public class ClientProxy extends CommonProxy {
    @Override
    public void preInit(FMLPreInitializationEvent e) {
        ColorSettings.load(e.getModConfigurationDirectory());
        RenderingRegistry.registerEntityRenderingHandler(EntityLightningBolt.class, new IRenderFactory<EntityLightningBolt>() {
            @Override
            public Render<? super EntityLightningBolt> createRenderFor(RenderManager manager) {
                return new RenderColoredLightning(manager);
            }
        });
        MinecraftForge.EVENT_BUS.register(new ClientEvents());
        ClientRegistry.registerKeyBinding(ClientEvents.KEY);
        ClientCommandHandler.instance.registerCommand(new CommandRenk());
    }
}
