package com.multiverse;

import net.minecraft.client.Minecraft;
import net.minecraft.client.multiplayer.WorldClient;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.world.WorldProvider;
import net.minecraftforge.client.IRenderHandler;
import net.minecraftforge.fml.relauncher.Side;
import net.minecraftforge.fml.relauncher.SideOnly;

@SideOnly(Side.CLIENT)
public class ClientHooks {
    public static void setup(WorldProvider p) {
        p.setSkyRenderer(new SkyDome());
        p.setCloudRenderer(new NoClouds());
    }

    public static class NoClouds extends IRenderHandler {
        @Override
        public void render(float partialTicks, WorldClient world, Minecraft mc) {
        }
    }

    public static class SkyDome extends IRenderHandler {
        @Override
        public void render(float partialTicks, WorldClient world, Minecraft mc) {
            Theme t = Themes.byDimension(world.provider.getDimension());
            int c = ColorSettings.customSky ? ColorSettings.sky : (t == null ? 0x78A7FF : t.sky);
            int r = (c >> 16) & 255, g = (c >> 8) & 255, bl = c & 255;
            final int A = 100;
            GlStateManager.disableTexture2D();
            GlStateManager.disableCull();
            GlStateManager.depthMask(false);
            Tessellator ts = Tessellator.getInstance();
            BufferBuilder b = ts.getBuffer();
            b.begin(7, DefaultVertexFormats.POSITION_COLOR);
            v(b, -A, -A, -A, r, g, bl); v(b, A, -A, -A, r, g, bl); v(b, A, A, -A, r, g, bl); v(b, -A, A, -A, r, g, bl);
            v(b, -A, -A, A, r, g, bl); v(b, -A, A, A, r, g, bl); v(b, A, A, A, r, g, bl); v(b, A, -A, A, r, g, bl);
            v(b, -A, -A, -A, r, g, bl); v(b, -A, -A, A, r, g, bl); v(b, A, -A, A, r, g, bl); v(b, A, -A, -A, r, g, bl);
            v(b, -A, A, -A, r, g, bl); v(b, A, A, -A, r, g, bl); v(b, A, A, A, r, g, bl); v(b, -A, A, A, r, g, bl);
            v(b, -A, -A, -A, r, g, bl); v(b, -A, A, -A, r, g, bl); v(b, -A, A, A, r, g, bl); v(b, -A, -A, A, r, g, bl);
            v(b, A, -A, -A, r, g, bl); v(b, A, -A, A, r, g, bl); v(b, A, A, A, r, g, bl); v(b, A, A, -A, r, g, bl);
            ts.draw();
            GlStateManager.depthMask(true);
            GlStateManager.enableCull();
            GlStateManager.enableTexture2D();
        }

        private static void v(BufferBuilder b, double x, double y, double z, int r, int g, int bl) {
            b.pos(x, y, z).color(r, g, bl, 255).endVertex();
        }
    }
}
