package com.multiverse;

import net.minecraft.block.state.IBlockState;

public class Theme {
    public final int index, sky, grass, base;
    public final String name;
    public final IBlockState top, filler;
    public final IBlockState liquid;
    public final boolean castle;

    public Theme(int index, String name, int sky, int grass, IBlockState top, IBlockState filler, int base, IBlockState liquid, boolean castle) {
        this.index = index;
        this.name = name;
        this.sky = sky;
        this.grass = grass;
        this.top = top;
        this.filler = filler;
        this.base = base;
        this.liquid = liquid;
        this.castle = castle;
    }
}
