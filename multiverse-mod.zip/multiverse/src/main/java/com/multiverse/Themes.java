package com.multiverse;

import net.minecraft.block.Block;
import net.minecraft.init.Blocks;

public class Themes {
    public static final int BASE = 100;
    public static final int COUNT = 85;
    public static final Theme[] ALL = new Theme[COUNT];
    private static int n = 0;

    static {
        add("Karanlık", 0x000000, 0x2A2A2A, Blocks.GRASS, Blocks.DIRT, 64, null, true);
        add("Ateş", 0x5A1500, 0xCC4400, Blocks.NETHERRACK, Blocks.NETHERRACK, 64, null, false);
        add("Buz", 0xBFE6FF, 0xCFF0FF, Blocks.SNOW, Blocks.PACKED_ICE, 64, null, false);
        add("Çöl", 0xFFE0A0, 0xD2B060, Blocks.SAND, Blocks.SANDSTONE, 64, null, false);
        add("Orman", 0x8CC8FF, 0x1E7A2E, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Okyanus", 0x3A7BFF, 0x30A0C0, Blocks.SAND, Blocks.SANDSTONE, 52, Blocks.WATER, false);
        add("Gökkuşağı", 0xFFB0FF, 0xFF66FF, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Şeker", 0xFFD6EE, 0xFF88CC, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Zehir", 0x2C4400, 0x66FF00, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Gün Batımı", 0xFF7A45, 0xD99A33, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Gece", 0x050520, 0x1B4A7A, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Altın", 0xFFE680, 0xE6C200, Blocks.HARDENED_CLAY, Blocks.HARDENED_CLAY, 64, null, false);
        add("End", 0x14001F, 0xC8C88A, Blocks.END_STONE, Blocks.END_STONE, 64, null, false);
        add("Nether", 0x2A0A0A, 0xAA3300, Blocks.SOUL_SAND, Blocks.NETHERRACK, 64, null, false);
        add("Mantar", 0xB8A0C8, 0x8866AA, Blocks.MYCELIUM, Blocks.DIRT, 64, null, false);
        add("Bataklık", 0x3F5240, 0x4A5D23, Blocks.GRASS, Blocks.DIRT, 61, Blocks.WATER, false);
        add("Mor", 0x6A25A8, 0xAA44FF, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Mavi", 0x4A8CFF, 0x2266FF, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Beyaz", 0xFFFFFF, 0xEFEFEF, Blocks.SNOW, Blocks.QUARTZ_BLOCK, 64, null, false);
        add("Kırmızı", 0x8A0000, 0xFF2222, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Kan Yağmuru", 0x4A0000, 0x8B0000, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Kemik Çölü", 0xB8B09A, 0xCFC9B0, Blocks.BONE_BLOCK, Blocks.SANDSTONE, 64, null, false);
        add("Ölü Orman", 0x2B2B26, 0x4B4B2F, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Çürümüş Bataklık", 0x2E3A1E, 0x55612A, Blocks.GRASS, Blocks.DIRT, 61, Blocks.WATER, false);
        add("Lav Gölü", 0x401000, 0x802000, Blocks.MAGMA, Blocks.NETHERRACK, 57, Blocks.LAVA, false);
        add("Cinnet Evreni", 0xFF0033, 0xFF0033, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Katil Gecesi", 0x020008, 0x112211, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Hayalet Sisi", 0xC8D0D0, 0x9AA8A8, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Cadı Ormanı", 0x1A0A2A, 0x3D1A5A, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Zombi Çiftliği", 0x4A5A30, 0x5A7A2A, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Mezarlık", 0x1C1C24, 0x2F3A2F, Blocks.MOSSY_COBBLESTONE, Blocks.DIRT, 64, null, false);
        add("Terk Edilmiş Hastane", 0xDDE8E0, 0xB8C8B8, Blocks.QUARTZ_BLOCK, Blocks.STONE, 64, null, false);
        add("Karanlık Mağara", 0x000000, 0x1A1A1A, Blocks.STONE, Blocks.STONE, 64, null, false);
        add("Kuru Kan Çölü", 0x7A2A10, 0xA04020, Blocks.RED_SANDSTONE, Blocks.RED_SANDSTONE, 64, null, false);
        add("Kırmızı Ay", 0x300000, 0x701010, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Siyah Güneş", 0x15100A, 0x3A2A10, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Çığlık Vadisi", 0x3A2A3A, 0x6A4A6A, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Zehirli Bataklık", 0x1A3A10, 0x80FF00, Blocks.GRASS, Blocks.DIRT, 61, Blocks.WATER, false);
        add("Kafatası Dağı", 0xAAA090, 0xDDD5C0, Blocks.BONE_BLOCK, Blocks.BONE_BLOCK, 64, null, false);
        add("Işıksız Ova", 0x050505, 0x202020, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Beyaz Kabus", 0xFFFFFF, 0xFFFFFF, Blocks.SNOW, Blocks.QUARTZ_BLOCK, 64, null, false);
        add("Lav Okyanusu", 0x500000, 0x900000, Blocks.NETHER_WART_BLOCK, Blocks.NETHERRACK, 50, Blocks.LAVA, false);
        add("Çıldırmış Gökyüzü", 0xFF00FF, 0x00FF99, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Yanık Orman", 0x2A1A10, 0x3A2A1A, Blocks.COAL_BLOCK, Blocks.GRAVEL, 64, null, false);
        add("Küllü Çöl", 0x555555, 0x777777, Blocks.GRAVEL, Blocks.GRAVEL, 64, null, false);
        add("Acı Çığlığı", 0x600030, 0xAA0055, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Gölge Diyarı", 0x08080F, 0x18182A, Blocks.OBSIDIAN, Blocks.OBSIDIAN, 64, null, false);
        add("Ruh Kumu Vadisi", 0x3A2A1A, 0x6A5A3A, Blocks.SOUL_SAND, Blocks.SOUL_SAND, 64, null, false);
        add("Cehennem Ağzı", 0x701500, 0xFF5500, Blocks.MAGMA, Blocks.NETHERRACK, 64, null, false);
        add("Terk Edilmiş Kasaba", 0x4A4A55, 0x6A6A55, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Hasta Orman", 0x6A7A20, 0x9AAA30, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Mor Zehir", 0x3A0A4A, 0x9A20D0, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Kemik Ormanı", 0x909090, 0xDADADA, Blocks.BONE_BLOCK, Blocks.DIRT, 64, null, false);
        add("Siyah Sis", 0x101418, 0x253035, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Kıyamet Günü", 0x7A1A00, 0xCC3300, Blocks.NETHERRACK, Blocks.STONE, 64, null, false);
        add("Et Diyarı", 0xC080A0, 0xD070A0, Blocks.NETHER_WART_BLOCK, Blocks.NETHERRACK, 64, null, false);
        add("Pas Evreni", 0x6A4A30, 0x9A5A30, Blocks.HARDENED_CLAY, Blocks.HARDENED_CLAY, 64, null, false);
        add("Ölüm Sessizliği", 0x181818, 0x303030, Blocks.STONE, Blocks.STONE, 64, null, false);
        add("Karabasan", 0x200030, 0x500070, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Çıplak Dağ", 0x808080, 0x999999, Blocks.STONE, Blocks.STONE, 64, null, false);
        add("Kızıl Bataklık", 0x401818, 0x803020, Blocks.GRASS, Blocks.DIRT, 61, Blocks.WATER, false);
        add("Kurukafa Denizi", 0x303040, 0xA0A0A0, Blocks.BONE_BLOCK, Blocks.SANDSTONE, 52, Blocks.WATER, false);
        add("Delilik", 0xFFFF00, 0xFF8800, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Gözyaşı Gölü", 0x3A4A5A, 0x4A6A7A, Blocks.GRASS, Blocks.DIRT, 60, Blocks.WATER, false);
        add("Kanlı Kar", 0xFFD0D0, 0xFF8080, Blocks.SNOW, Blocks.PACKED_ICE, 64, null, false);
        add("Karanlık Buz", 0x0A1020, 0x203050, Blocks.PACKED_ICE, Blocks.PACKED_ICE, 64, null, false);
        add("Çürük Yumurta", 0x8A8A30, 0xAAAA20, Blocks.CLAY, Blocks.CLAY, 64, null, false);
        add("Toksik Atık", 0x20FF20, 0x30FF30, Blocks.SLIME_BLOCK, Blocks.DIRT, 64, null, false);
        add("Bozuk Dünya", 0x00FFFF, 0xFF00FF, Blocks.PURPLE_GLAZED_TERRACOTTA, Blocks.BLACK_GLAZED_TERRACOTTA, 64, null, false);
        add("Sonsuz Karanlık", 0x000000, 0x000000, Blocks.BLACK_GLAZED_TERRACOTTA, Blocks.COAL_BLOCK, 64, null, false);
        add("Kan Ormanı", 0x6A0000, 0xAA0000, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("İnsan Avı", 0x2A1A0A, 0x4A3A1A, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Karışık Cesetler", 0x303820, 0x606840, Blocks.MYCELIUM, Blocks.DIRT, 64, null, false);
        add("Yalnız Ev", 0x484850, 0x586058, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Siyah Gül Bahçesi", 0x10000A, 0x300020, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Çürük Elma", 0x5A2A10, 0x7A4A18, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Şeytan Tapınağı", 0x500010, 0xB01030, Blocks.RED_GLAZED_TERRACOTTA, Blocks.NETHER_BRICK, 64, null, false);
        add("Ay Işıksız Gece", 0x03030A, 0x0A1A0A, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Karnaval Kabusu", 0xFF3060, 0x30FF60, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Eski Kuyu", 0x202820, 0x3A4A3A, Blocks.COBBLESTONE, Blocks.STONE, 64, null, false);
        add("Ölü Deniz", 0x404848, 0x707868, Blocks.SAND, Blocks.SANDSTONE, 50, Blocks.WATER, false);
        add("Gri Cehennem", 0x303030, 0x505050, Blocks.GRAVEL, Blocks.STONE, 58, Blocks.LAVA, false);
        add("Takıntı", 0xFF0000, 0x000000, Blocks.GRASS, Blocks.DIRT, 64, null, false);
        add("Son Çığlık", 0x180008, 0x440020, Blocks.NETHER_WART_BLOCK, Blocks.NETHERRACK, 64, null, false);
        add("Psikopat Evreni", 0x000000, 0xFF0000, Blocks.GRASS, Blocks.DIRT, 64, null, false);
    }

    private static void add(String name, int sky, int grass, Block top, Block filler, int base, Block liquid, boolean castle) {
        ALL[n] = new Theme(n, name, sky, grass, top.getDefaultState(), filler.getDefaultState(), base,
                liquid == null ? null : liquid.getDefaultState(), castle);
        n++;
    }

    public static Theme byDimension(int dim) {
        int i = dim - BASE;
        return (i >= 0 && i < COUNT) ? ALL[i] : null;
    }
}
