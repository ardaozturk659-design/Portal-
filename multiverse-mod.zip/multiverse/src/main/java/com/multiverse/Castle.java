package com.multiverse;

import net.minecraft.block.state.IBlockState;
import net.minecraft.init.Blocks;

public class Castle {
    private static final IBlockState AIR = Blocks.AIR.getDefaultState();
    private static final IBlockState COAL = Blocks.COAL_BLOCK.getDefaultState();
    private static final IBlockState OBSIDIAN = Blocks.OBSIDIAN.getDefaultState();
    private static final IBlockState NETHER = Blocks.NETHER_BRICK.getDefaultState();
    private static final IBlockState STONEBRICK = Blocks.STONEBRICK.getDefaultState();
    private static final IBlockState BARS = Blocks.IRON_BARS.getDefaultState();

    /** null = bu noktada kale yok (arazi kalsin) */
    public static IBlockState block(int x, int y, int z) {
        if (y < 63 || y > 170) return null;
        int ax = Math.abs(x), az = Math.abs(z);
        if (ax > 56 || az > 56) return null;
        int m = Math.max(ax, az);

        if (y == 63) {
            if (m <= 39) return ((x + z) & 1) == 0 ? OBSIDIAN : COAL;
            return null;
        }

        // koseki kuleler
        int sx = x < 0 ? -1 : 1, sz = z < 0 ? -1 : 1;
        int dx = x - 44 * sx, dz = z - 44 * sz;
        int d2 = dx * dx + dz * dz;
        if (d2 <= 81) {
            IBlockState t = tower(y, d2, dx, dz);
            if (t != null) return t;
        }

        // dis sur
        if (m >= 40 && m <= 44 && y <= 85) {
            if (z < 0 && az >= 40 && ax <= 3 && y <= 74) return AIR; // kapi
            if (y == 85) return ((m == 44 || m == 40) && ((x + z) & 1) == 0) ? COAL : null;
            return (((x + z) & 7) == 0) ? NETHER : COAL;
        }

        int dc = x * x + z * z;

        // ana kule
        if (dc <= 81 && y >= 101 && y <= 140) {
            if (dc >= 49) {
                boolean win = (y % 12 == 5 || y % 12 == 6) && (x == 0 || z == 0);
                return win ? BARS : OBSIDIAN;
            }
            if (y == 112 || y == 124) return STONEBRICK;
            return AIR;
        }
        if (dc <= 100 && y > 140 && y <= 165) {
            double r = 9.5 - (y - 140) * 0.38;
            return (r > 0 && dc <= r * r) ? NETHER : null;
        }

        // ic kale (keep)
        if (m <= 16 && y <= 100) {
            if (m >= 13) {
                if (z < 0 && az >= 13 && ax <= 2 && y <= 69) return AIR; // kapi
                boolean win = y >= 70 && (y % 12 == 10 || y % 12 == 11)
                        && ((az == m && ax % 4 == 0) || (ax == m && az % 4 == 0));
                return win ? BARS : OBSIDIAN;
            }
            if (y == 76 || y == 88) return STONEBRICK;
            if (y == 100) return dc <= 64 ? AIR : STONEBRICK;
            return AIR;
        }
        if (m <= 16 && y == 101) {
            return (m == 16 && ((x + z) & 1) == 0) ? COAL : null;
        }
        return null;
    }

    private static IBlockState tower(int y, int d2, int dx, int dz) {
        if (y <= 110) {
            if (d2 > 64) return null;
            if (d2 >= 36) {
                boolean win = (y % 12 == 8 || y % 12 == 9) && (dx == 0 || dz == 0);
                return win ? BARS : OBSIDIAN;
            }
            if (y == 76 || y == 90 || y == 104) return STONEBRICK;
            return AIR;
        } else if (y <= 125) {
            double r = 9.0 - (y - 110) * 0.6;
            return (r > 0 && d2 <= r * r) ? NETHER : null;
        }
        return null;
    }
}
