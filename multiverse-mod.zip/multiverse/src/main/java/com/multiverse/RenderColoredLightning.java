package com.multiverse;

import java.util.Random;
import net.minecraft.client.renderer.BufferBuilder;
import net.minecraft.client.renderer.GlStateManager;
import net.minecraft.client.renderer.Tessellator;
import net.minecraft.client.renderer.entity.Render;
import net.minecraft.client.renderer.entity.RenderManager;
import net.minecraft.client.renderer.vertex.DefaultVertexFormats;
import net.minecraft.entity.effect.EntityLightningBolt;
import net.minecraft.util.ResourceLocation;

public class RenderColoredLightning extends Render<EntityLightningBolt> {
    public RenderColoredLightning(RenderManager manager) {
        super(manager);
    }

    @Override
    public void doRender(EntityLightningBolt entity, double x, double y, double z, float entityYaw, float partialTicks) {
        float cr = 0.45F, cg = 0.45F, cb = 0.5F, ca = 0.3F;
        boolean custom = ColorSettings.customLightning;
        if (custom) {
            int c = ColorSettings.lightning;
            cr = ((c >> 16) & 255) / 255f;
            cg = ((c >> 8) & 255) / 255f;
            cb = (c & 255) / 255f;
            ca = 0.85F;
        }
        Tessellator tessellator = Tessellator.getInstance();
        BufferBuilder buf = tessellator.getBuffer();
        GlStateManager.disableTexture2D();
        GlStateManager.disableLighting();
        GlStateManager.enableBlend();
        if (custom) {
            GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        } else {
            GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE);
        }
        double[] ax = new double[8];
        double[] az = new double[8];
        double d0 = 0.0D, d1 = 0.0D;
        Random random = new Random(entity.boltVertex);
        for (int i = 7; i >= 0; --i) {
            ax[i] = d0;
            az[i] = d1;
            d0 += (double) (random.nextInt(11) - 5);
            d1 += (double) (random.nextInt(11) - 5);
        }
        for (int k1 = 0; k1 < 4; ++k1) {
            Random random1 = new Random(entity.boltVertex);
            for (int j = 0; j < 3; ++j) {
                int k = 7;
                int l = 0;
                if (j > 0) k = 7 - j;
                if (j > 0) l = k - 2;
                double d2 = ax[k] - d0;
                double d3 = az[k] - d1;
                for (int i1 = k; i1 >= l; --i1) {
                    double d4 = d2;
                    double d5 = d3;
                    d2 += (double) (random1.nextInt(11) - 5);
                    d3 += (double) (random1.nextInt(11) - 5);
                    buf.begin(5, DefaultVertexFormats.POSITION_COLOR);
                    double d6 = 0.1D + (double) k1 * 0.2D;
                    if (j == 0) d6 *= (double) i1 * 0.1D + 1.0D;
                    double d7 = 0.1D + (double) k1 * 0.2D;
                    if (j == 0) d7 *= (double) (i1 - 1) * 0.1D + 1.0D;
                    for (int j1 = 0; j1 < 5; ++j1) {
                        double d8 = x + 0.5D - d6;
                        double d9 = z + 0.5D - d6;
                        if (j1 == 1 || j1 == 2) d8 += d6 * 2.0D;
                        if (j1 == 2 || j1 == 3) d9 += d6 * 2.0D;
                        double d10 = x + 0.5D - d7;
                        double d11 = z + 0.5D - d7;
                        if (j1 == 1 || j1 == 2) d10 += d7 * 2.0D;
                        if (j1 == 2 || j1 == 3) d11 += d7 * 2.0D;
                        buf.pos(d10 + d2, y + (double) (i1 * 16), d11 + d3).color(cr, cg, cb, ca).endVertex();
                        buf.pos(d8 + d4, y + (double) ((i1 + 1) * 16), d9 + d5).color(cr, cg, cb, ca).endVertex();
                    }
                    tessellator.draw();
                }
            }
        }
        GlStateManager.blendFunc(GlStateManager.SourceFactor.SRC_ALPHA, GlStateManager.DestFactor.ONE_MINUS_SRC_ALPHA);
        GlStateManager.disableBlend();
        GlStateManager.enableLighting();
        GlStateManager.enableTexture2D();
    }

    @Override
    protected ResourceLocation getEntityTexture(EntityLightningBolt entity) {
        return null;
    }
}
